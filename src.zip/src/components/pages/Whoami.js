import React from 'react';
import '../../App.css';

export default function Whoami() {
  return <h1 className='whoami'>Who am I? </h1>;
}
