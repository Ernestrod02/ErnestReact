import React from 'react';
import '../../App.css';

export default function Support() {
  return <h1 className='support'>Support Page in progress</h1>;
}
