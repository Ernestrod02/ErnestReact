import React from 'react';
import '../../App.css';

export default function Job() {
  return <h1 className='job'>JOB WIP</h1>;
}
