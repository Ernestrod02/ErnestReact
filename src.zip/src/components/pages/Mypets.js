import React from 'react';
import '../../App.css';

export default function Mypets() {
  return <h1 className='mypets'>MYPETS WIP</h1>;
}
