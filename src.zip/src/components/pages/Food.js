import React from 'react';
import '../../App.css';

export default function Food() {
  return <h1 className='food'>FOOD WIP</h1>;
}
