import React from 'react';
import '../../App.css';

export default function Contact() {
  return <h1 className='contact'>Contact page is a work in progress</h1>;
}
