import React from 'react';
import '../../App.css';

export default function From() {
  return <h1 className='from'>FROM WIP</h1>;
}
