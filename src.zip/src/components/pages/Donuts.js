import React from 'react';
import '../../App.css';

export default function Donuts() {
  return <h1 className='donuts'>Best Donuts</h1>;
}
