import React from 'react';
import '../../App.css';

export default function Been() {
  return <h1 className='been'>BEEN WIP</h1>;
}
